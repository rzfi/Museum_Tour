import React from 'react'

function MuseumCard() {
  return (
    <div>MuseumCard</div>
  )
}

export default MuseumCard