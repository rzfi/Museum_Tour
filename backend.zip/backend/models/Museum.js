const mongoose = require('mongoose');

const museumSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true
    },
    location: {
        address: {
            type: String,
            required: true
        },
        city: {
            type: String,
            required: true
        },
        state: {
            type: String,
            required: true
        },
        country: {
            type: String,
            required: true
        },
        zipCode: {
            type: String,
            required: true
        }
    },
    images: [{
        url: String,
        caption: String
    }]
}, {
    timestamps: true
});

module.exports = mongoose.model('Museum', museumSchema);
